This is an example directory structure that compiles a Rust hello world
example. It is intended to show how to set up a simple Rust GN build.

Don't miss the ".gn" file in this directory!
